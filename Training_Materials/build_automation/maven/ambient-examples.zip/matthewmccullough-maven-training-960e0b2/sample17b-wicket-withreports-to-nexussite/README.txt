This project provides a chance to demonstrate the maven site and reporting tools:

mvn site site:deploy

Wired to output to: /Users/mccm06/Sites/sample14
Accessible via: http://localhost/~mccm06/sample14/