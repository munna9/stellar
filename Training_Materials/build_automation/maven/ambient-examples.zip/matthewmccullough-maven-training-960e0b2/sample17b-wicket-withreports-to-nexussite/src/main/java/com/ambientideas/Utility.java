package com.ambientideas;

/**
 * Homepage
 */
public class Utility {

	private static final long serialVersionUID = 1L;

    public void worthlessMethod() {
        System.out.println("This is boilerplate output");
        System.out.println("This is more boilerplate output");
        System.out.println("This is even more boilerplate output");
        System.out.println("This is boilerplate output");
        System.out.println("This is more boilerplate output");
        System.out.println("This is even more boilerplate output");
        System.out.println("This is boilerplate output");
        System.out.println("This is more boilerplate output");
        System.out.println("This is even more boilerplate output");
        System.out.println("This is boilerplate output");
        System.out.println("This is more boilerplate output");
        System.out.println("This is even more boilerplate output");
        
        //TODO Clean up this copy-and-paste
    }
}
