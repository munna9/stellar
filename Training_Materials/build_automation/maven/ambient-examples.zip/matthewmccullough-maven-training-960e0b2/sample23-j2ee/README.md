# Maven J2EE Archetype
A simple J2EE app generated from the J2EE archetype. Had to clean it up and remove the `<site>` module (currently broken 1.0 vintage archetype)

## Goal
X

## Start
X
