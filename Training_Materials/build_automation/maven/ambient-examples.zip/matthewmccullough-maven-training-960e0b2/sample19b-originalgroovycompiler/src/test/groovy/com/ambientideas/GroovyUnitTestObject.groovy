package com.ambientideas;

public class GroovyUnitTestObject
{
	def attr = "DemoData"
}
