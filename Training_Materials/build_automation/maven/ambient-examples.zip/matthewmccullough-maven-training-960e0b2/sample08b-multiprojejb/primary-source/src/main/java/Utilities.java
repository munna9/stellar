public class Utilities {
    public static boolean stillAlive() {
        return true;
    }
}