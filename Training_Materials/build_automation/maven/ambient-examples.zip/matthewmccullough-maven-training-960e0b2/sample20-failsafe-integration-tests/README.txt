This project implements the Failsafe plugin pattern that allows for unit tests and integration tests to reside in the same directory.

As of January 4th, 2010, the Failsafe plugin is being merged with the Surefire plugin.
http://old.nabble.com/-Vote-Proposal-%3A-failsafe-and-surefire-ts27016430.html

Many other approaches are listed on this Codehaus wiki page:
http://docs.codehaus.org/display/MAVENUSER/Maven+and+Integration+Testing
