package com.ambientideas;

import org.junit.Test;

/**
 * Unit test for simple App.
 */
public class AppIT 
{
    /**
     * Rigourous Test :-)
     */
     @Test
    public void testApp()
    {
    	System.out.println("This is an Integration Test!");
    	App.main(null);
    }
}
