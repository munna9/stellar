//
// Generated from archetype; please customize.
//

package com.ambientideas;

/**
 * Example Java class.
 */
public class Helper
{
    public void help(final Example example) {
        example.show();
    }
}
