//
// Generated from archetype; please customize.
//

package com.ambientideas

/**
 * Example Groovy class.
 */
class Example
{
    def show() {
        println 'Hello World'
    }
}
