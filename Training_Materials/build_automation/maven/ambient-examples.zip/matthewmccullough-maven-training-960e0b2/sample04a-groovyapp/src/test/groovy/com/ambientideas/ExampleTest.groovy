//
// Generated from archetype; please customize.
//

package com.ambientideas

import groovy.util.GroovyTestCase

/**
 * Tests for the {@link Example} class.
 */
class ExampleTest
    extends GroovyTestCase
{
    void testShow() {
        new Example().show()
    }
}
