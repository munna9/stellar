package com.ambientideas

import com.ambientideas.Helper

public class Main {
	public static void main(String[] args) {
	  println "Hello from callHelp!"
	}

	public static void callHelp() {
	  Helper.printHelp()
	}
}