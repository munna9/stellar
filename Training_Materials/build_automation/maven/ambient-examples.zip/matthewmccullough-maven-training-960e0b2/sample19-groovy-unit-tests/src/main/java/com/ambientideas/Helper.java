package com.ambientideas;

public class Helper
{
    public static void printHelp() {
        System.out.println("This is all you get for help folks.");
    }
}
