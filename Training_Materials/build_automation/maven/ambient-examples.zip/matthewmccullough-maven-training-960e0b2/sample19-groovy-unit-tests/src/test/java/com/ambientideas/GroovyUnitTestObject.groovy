package com.ambientideas;

public class GroovyUnitTestObject
{
	public def attr = "DemoData"
}
