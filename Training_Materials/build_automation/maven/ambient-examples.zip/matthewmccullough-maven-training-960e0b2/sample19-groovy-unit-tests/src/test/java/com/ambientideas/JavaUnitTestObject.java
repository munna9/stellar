package com.ambientideas;

public class JavaUnitTestObject
{
	String attr = "DemoData";
}
